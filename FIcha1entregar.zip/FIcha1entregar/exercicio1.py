a = int(input ("introduza o numero que deseja "))
antecedor = int(a)-1 
sucessor = int(a)+1

print ("antecedor:", antecedor)
print ("sucessor:", sucessor) 