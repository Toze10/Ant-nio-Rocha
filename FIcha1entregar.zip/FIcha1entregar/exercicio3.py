a = float(input ("Indique o seu peso"))
b = float(input ("Indique a sua altura em metros"))

Imc = (a / b**2)

print ("O seu IMC é de ", Imc )