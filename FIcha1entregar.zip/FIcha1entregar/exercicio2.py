F = int(input ("Indique a temperatura " ))
C = (F - 32 ) * 5 / 9 

print ("Temperatura em C é ", C) 